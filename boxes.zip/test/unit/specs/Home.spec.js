import Vue from 'vue'
import Home from '@/components/Home.vue'

describe('Home.vue', () => {

})
